import os
import sys
import yaml
import joblib
import mlflow
import logging
import numpy as np
import pandas as pd
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
import time
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response

# Add monitoring module to path
sys.path.append('/app/monitoring/src')
from drift.drift_collector import DriftDataCollector

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load configuration
config_path = Path(__file__).parent.parent.parent / "config" / "api_config.yaml"
with open(config_path, 'r') as f:
    config = yaml.safe_load(f)

# Global variables for model and encoders
model = None
label_encoders = None
drift_collector = None

# Prometheus Metrics
REQUEST_COUNT = Counter(
    'loan_api_requests_total', 'Total number of requests',
    ['endpoint', 'method']
)
REQUEST_DURATION = Histogram(
    'loan_api_request_duration_seconds', 'Request duration in seconds',
    ['endpoint', 'method']
)
LOAN_APPROVAL_COUNT = Counter(
    'loan_api_approvals_total', 'Total number of loan approvals',
    ['approved']
)
AVG_RISK_SCORE = Gauge(
    'loan_api_avg_risk_score', 'Average risk score of approved loans'
)
ACTIVE_REQUESTS = Gauge(
    'loan_api_active_requests', 'Number of active requests'
)

class LoanApplication(BaseModel):
    """Loan application input schema."""
    age: float
    annual_income: float
    credit_score: float
    experience: float
    loan_amount: float
    loan_duration: float
    number_of_dependents: float
    monthly_debt_payments: float
    credit_card_utilization_rate: float
    number_of_open_credit_lines: float
    number_of_credit_inquiries: float
    debt_to_income_ratio: float
    bankruptcy_history: float
    previous_loan_defaults: float
    payment_history: float
    length_of_credit_history: float
    savings_account_balance: float
    checking_account_balance: float
    total_assets: float
    total_liabilities: float
    monthly_income: float
    job_tenure: float
    net_worth: float
    employment_status: str = "Employed"
    education_level: str = "Bachelor"
    marital_status: str = "Married"
    home_ownership_status: str = "Own"
    loan_purpose: str = "Home"

class LoanPrediction(BaseModel):
    """Loan prediction response schema."""
    approved: bool
    probability: float
    risk_score: float
    confidence: str

class HealthResponse(BaseModel):
    """Health check response schema."""
    status: str
    model_loaded: bool

# Simple metrics tracking for backward compatibility
class SimpleMetrics:
    def __init__(self):
        self.requests = 0
        self.approvals = 0
        self.total_risk_score = 0
    
    def record_prediction(self, approved: bool, risk_score: float):
        self.requests += 1
        if approved:
            self.approvals += 1
        self.total_risk_score += risk_score
    
    def get_stats(self):
        return {
            "total_requests": self.requests,
            "approvals": self.approvals,
            "approval_rate": self.approvals / self.requests if self.requests > 0 else 0,
            "avg_risk_score": self.total_risk_score / self.requests if self.requests > 0 else 0
        }

metrics = SimpleMetrics()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize MLflow and load the production model."""
    global model, label_encoders, drift_collector
    try:
        mlflow.set_tracking_uri("http://localhost:5000")
        logger.info("MLflow tracking URI set successfully")
        
        # Try to load model from local file first
        model_path = Path(config["model"]["model_path"])
        encoders_path = model_path.parent / "label_encoders.joblib"
        
        if model_path.exists() and encoders_path.exists():
            model = joblib.load(model_path)
            label_encoders = joblib.load(encoders_path)
            logger.info(f"Model and encoders loaded from {model_path}")
        else:
            # Create a dummy model if no fallback to MLflow
            from sklearn.ensemble import RandomForestClassifier
            model = RandomForestClassifier(n_estimators=10, random_state=42)
            logger.warning("No model found, using dummy model for predictions.")
        
        # Initialize drift collector
        try:
            drift_collector = DriftDataCollector(
                api_url="http://prediction-api:8000",
                reference_data_path="data/raw/focused_synthetic_loan_data.csv"
            )
            logger.info("Drift collector initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize drift collector: {e}")
            drift_collector = None
        
        yield
    except Exception as e:
        logger.error(f"Error during startup: {str(e)}")
        raise
    finally:
        pass

# Create FastAPI app
app = FastAPI(
    title="Loan Approval API",
    description="API for predicting loan approval based on applicant features",
    version="1.0.0",
    lifespan=lifespan
)

@app.middleware("http")
async def prometheus_middleware(request: Request, call_next):
    """Middleware to track Prometheus metrics."""
    start_time = time.time()
    ACTIVE_REQUESTS.inc()
    
    try:
        response = await call_next(request)
        REQUEST_COUNT.labels(method=request.method, endpoint=request.url.path).inc()
        return response
    finally:
        REQUEST_DURATION.labels(method=request.method, endpoint=request.url.path).observe(time.time() - start_time)
        ACTIVE_REQUESTS.dec()

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    REQUEST_COUNT.labels(endpoint="/health", method="GET").inc()
    return HealthResponse(
        status="healthy",
        model_loaded=model is not None
    )

@app.get("/metrics")
async def get_metrics():
    """Get simple metrics for backward compatibility."""
    REQUEST_COUNT.labels(endpoint="/metrics", method="GET").inc()
    return metrics.get_stats()

@app.get("/prometheus")
async def prometheus_metrics():
    """Expose Prometheus metrics."""
    REQUEST_COUNT.labels(endpoint="/prometheus", method="GET").inc()
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.post("/predict", response_model=LoanPrediction)
async def predict_loan_approval(application: LoanApplication):
    """Predict loan approval based on applicant features."""
    if model is None:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    try:
        # Convert application to DataFrame
        app_data = application.dict()
        
        # Map column names to encoder keys
        column_mapping = {
            'employment_status': 'EmploymentStatus',
            'education_level': 'EducationLevel', 
            'marital_status': 'MaritalStatus',
            'home_ownership_status': 'HomeOwnershipStatus',
            'loan_purpose': 'LoanPurpose'
        }
        
        # Encode categorical variables
        if label_encoders:
            for col, encoder_key in column_mapping.items():
                if col in app_data and encoder_key in label_encoders:
                    app_data[col] = label_encoders[encoder_key].transform([app_data[col]])[0]
        
        # Create feature vector
        features = np.array([[
            app_data['age'], app_data['annual_income'], app_data['credit_score'],
            app_data['experience'], app_data['loan_amount'], app_data['loan_duration'],
            app_data['number_of_dependents'], app_data['monthly_debt_payments'],
            app_data['credit_card_utilization_rate'], app_data['number_of_open_credit_lines'],
            app_data['number_of_credit_inquiries'], app_data['debt_to_income_ratio'],
            app_data['bankruptcy_history'], app_data['previous_loan_defaults'],
            app_data['payment_history'], app_data['length_of_credit_history'],
            app_data['savings_account_balance'], app_data['checking_account_balance'],
            app_data['total_assets'], app_data['total_liabilities'],
            app_data['monthly_income'], app_data['job_tenure'], app_data['net_worth'],
            app_data.get('employment_status', 0), app_data.get('education_level', 0),
            app_data.get('marital_status', 0), app_data.get('home_ownership_status', 0),
            app_data.get('loan_purpose', 0)
        ]])
        
        # Make prediction
        prediction = model.predict(features)[0]
        probability = model.predict_proba(features)[0][1] if hasattr(model, 'predict_proba') else 0.5
        
        # Calculate risk score (inverse of probability)
        risk_score = (1 - probability) * 100
        
        # Determine confidence
        if probability > 0.8 or probability < 0.2:
            confidence = "High"
        elif probability > 0.6 or probability < 0.4:
            confidence = "Medium"
        else:
            confidence = "Low"
        
        # Update metrics
        prediction_approved = bool(prediction)
        metrics.record_prediction(prediction_approved, risk_score)
        
        # Update Prometheus metrics
        LOAN_APPROVAL_COUNT.labels(approved=str(prediction_approved).lower()).inc()
        if prediction_approved:
            AVG_RISK_SCORE.set(risk_score)
        
        # Collect data for drift analysis
        if drift_collector:
            try:
                drift_data = app_data.copy()
                drift_data['approved'] = prediction_approved
                drift_data['risk_score'] = risk_score
                drift_collector.collect_request_data(drift_data)
            except Exception as e:
                logger.warning(f"Failed to collect drift data: {e}")
        
        return LoanPrediction(
            approved=prediction_approved,
            probability=float(probability),
            risk_score=float(risk_score),
            confidence=confidence
        )
        
    except Exception as e:
        logger.error(f"Prediction error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")

@app.post("/drift/collect")
async def collect_drift_data(application: LoanApplication):
    """Manually collect data for drift analysis."""
    if drift_collector is None:
        raise HTTPException(status_code=503, detail="Drift collector not available")
    
    try:
        drift_data = application.dict()
        drift_collector.collect_request_data(drift_data)
        return {"status": "collected"}
    except Exception as e:
        logger.error(f"Failed to collect drift data: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to collect drift data: {str(e)}")

@app.get("/drift/metrics")
async def get_drift_metrics():
    """Get current drift metrics."""
    if drift_collector is None:
        raise HTTPException(status_code=503, detail="Drift collector not available")
    
    try:
        return drift_collector.calculate_drift()
    except Exception as e:
        logger.error(f"Failed to get drift metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get drift metrics: {str(e)}")

@app.get("/drift/summary")
async def get_drift_summary():
    """Get drift data collection summary."""
    if drift_collector is None:
        raise HTTPException(status_code=503, detail="Drift collector not available")
    
    try:
        return drift_collector.get_summary()
    except Exception as e:
        logger.error(f"Failed to get drift summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get drift summary: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
